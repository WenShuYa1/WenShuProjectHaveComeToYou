let db = {}
//引入mysql模块
const mysql = require("mysql")
//连接配置
const conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin",
  database: "wenshududu"
})
//建立连接
conn.connect()
//准备sql语句
db.query = function (sql, callback) {
  conn.query(sql, (err, result) => {
    if (err) {
      // 第一个参数是错误信息，第二个参数是执行结果。
      callback(err, null)
      return
    }
    // 对result执行操作
    callback(null, result)
    return
  })
  //关闭连接
  // conn.end()
}

module.exports = db
