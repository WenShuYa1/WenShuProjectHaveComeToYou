// // 引入包
// const express = require('express')
// const http = require('http')
// const Sequelize = require('sequelize')
// // 实例化服务器
// const app = express()

// // 定义接口
// const port = 3000

// /**
//  * app.get 查询
//  * app.post 添加
//  * app.delete 删除
//  * app.put 修改
//  * ...
// **/

// app.get('/', (req, res) => {
//   // req 请求对象 req.query req.params  req.body
//   // res 响应对象 res.send() 返回数据给前端
//   res.send({
//     message: '获取成功',
//     code: 200
//   })
//   console.log('获取成功')
//   console.log(req)
// })

// const mysql = require("mysql")
// const conn = mysql.createConnection({       //4.连接配置  调用createConnection方法，这个方法需要一个对象。对象的属性为连接数据库的配置信息。
//   host: "localhost",                                     //主机名（服务器地址）
//   user: "root",                                          //用户名
//   password: "admin",                           //密码
//   database: "itheima"                          //数据库名字
// })
// conn.connect()                      //5.建立连接
// // let sql = "delete from demo where id = 3"         //6.创建sql语句
// conn.query('select * from emp', (err, result) => {                   //7.执行sql语句
//   // if (err) {
//   err.end(JSON.stringify(result))
//   // err.send({
//   // message: '获取成功',
//   // code: 200,
//   // data: result
//   // })
//   // return
//   // }
//   // if (result.affectedRows != 0) {         //判断delete语句是否执行成功
//   // console.log("删除成功！")
//   // } else {
//   // console.log("删除失败！")
//   // }
// })
// conn.end()           //8.结束连接  不能一直开启，会消耗资源（程序/数据库的内存，连接数等等）


// app.listen(port, () => {
//   console.log('创建服务器成功')
// })





const http = require("http")
const queryString = require("querystring")
const db = require("./js/db")


http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')



  // 转码成 utf-8
  res.writeHead(200, {
    'Content-Type': 'text/plain;charset=utf8'
  })

  // 查看所有数据
  if (req.url.startsWith('/data')) {
    // const origin = req.headers.origin
    // console.log(origin)

    // res.setHeader('Access-Control-Allow-Origin', origin)
    let sql = `select * from emp;`
    db.query(sql, (err, result) => {
      if (err) {
        res.end("查询失败，错误信息为：" + err)
      }
      // 返回数据
      res.end(JSON.stringify(result))
    })
  } else if (req.url.startsWith('/get')) {
    // 查询某一条数据
    let params = queryString.parse(req.url.split("?")[1])
    // console.log(params.id)
    let sql = `select * from emp where id = ${params.id};`

    db.query(sql, (err, ress) => {
      if (err) {
        res.end("查询失败，错误信息为：" + err)
      }
      res.end(JSON.stringify(ress))
    })
  } else if (req.url.startsWith('/add')) {
    // 新增一条数据
    let params = queryString.parse(req.url.split("?")[1])
    let sql = `insert into emp(id, name, age, job, salary, entrydate, managerid, dept_id) values (${null},${params.name}, ${params.age}, ${params.job}, ${params.salary}, ${params.entrydate}, ${params.managerid}, ${params.dept_id});`
    db.query(sql, (err, ress) => {
      if (err) {
        res.end("查询失败，错误信息为：" + err)
      }
      res.end(JSON.stringify({
        message: '添加成功',
        code: 200
      }))
    })
  } else if (req.url.startsWith('/del')) {
    // 删除某一条数据
    let params = queryString.parse(req.url.split('?')[1])
    let sql = `delete from emp where id = ${params.id};`
    db.query(sql, (err, ress) => {
      console.log(sql)
      if (err) {
        res.end("查询失败，错误信息为：" + err)
      }
      res.end(JSON.stringify({
        message: '删除成功',
        code: 200
      }))
    })
  } else if (req.url.startsWith('/edit')) {
    // 编辑修改
    let params = queryString.parse(req.url.split('?')[1])
    let sql = `update emp set name = ${params.name} where id = ${params.id}`
    db.query(sql, (err, ress) => {
      if (err) {
        res.end("查询失败，错误信息为：" + err)
      }
      res.end(JSON.stringify({
        message: '修改成功',
        code: 200
      }))
    })

  } else if (req.url.startsWith('/user')) {
    // user表新增数据
    let params = queryString.parse(req.url.split("?")[1])
    // 新增用户数据
    if (params.type == 1) {
      // add新增
      let sql = `insert into user(id, name, account, password ) values (${null}, ${params.account}, ${params.account}, ${params.password});`
      db.query(sql, (err, ress) => {

        if (err) {
          res.end("新增失败，错误信息为：" + err)
        }
        res.end(JSON.stringify({
          message: '注册成功',
          code: 200
        }))
      })

      // 登录
    } else if (params.type == 2) {
      let sql = `select * from user where account=${params.account} and password = ${params.password} `
      db.query(sql, (err, ress) => {

        if (err) {
          res.end("登录失败")
        }
        res.end(JSON.stringify({
          message: '登入成功',
          code: 200
        }))
      })

    }


  }



}).listen(3000, () => {
  console.log("服务器成功启动")
})
